package com.javaio.question4;

import java.io.*;
public class Main
{
	public static int no_columns_fun(String str)
	{
		String rows[]=str.split(",");
		int n=rows.length;
		return n;
	}
	public static String[] Csv_row(String str)
	{
		String rows[]=str.split(",");  
		return rows;  
	}
	public static void main(String[] args) 
	{
		Reader rdr1 = null,rdr2=null;
		BufferedReader bfrdr1 = null, bfrdr2=null;
		Writer wtr = null;
		BufferedWriter bfwtr = null;
		int no_rows=0,no_columns=0;
		String[][] csv= null;
		try 
		{
			rdr1 = new FileReader("E:\\praticejava\\ASSIGNMENT\\src\\com\\javaio\\question4\\Test_In.csv");
			bfrdr1 = new BufferedReader(rdr1);
			rdr2 = new FileReader("E:\\praticejava\\ASSIGNMENT\\src\\com\\javaio\\question4\\Test_In.csv");
			bfrdr2 = new BufferedReader(rdr2);
			String nextLine=null;
			while((nextLine=bfrdr1.readLine())!=null)
			{
				if(no_rows==0)
				{
					no_columns=no_columns_fun(nextLine);
				}
				no_rows+=1;
			}
			System.out.println(no_columns);
			System.out.println(no_rows);
			csv=new String[no_columns][no_rows];
			int j=0;
			wtr = new FileWriter("E:\\praticejava\\ASSIGNMENT\\src\\com\\javaio\\question4\\Test_Out.txt");
			bfwtr = new BufferedWriter(wtr);
			while((nextLine=bfrdr2.readLine())!=null)
			{
				
				bfwtr.newLine();
				for(int i=0;i<Csv_row(nextLine).length;i++)
				{
					csv[i][j]=Csv_row(nextLine)[i];
					bfwtr.write(csv[i][j]);
					bfwtr.newLine();
				}
				j=j+1;
			}
		}
		catch(Exception e)
		{
			System.out.println("problem with reading the file");
		}
		finally
		{
			try
			{
				if(bfrdr1!=null)
					bfrdr1.close();
			}
			catch(Exception e)
			{
				System.out.println("could not close buffered reader: "+e);
			}
			try
			{
				if(bfrdr2!=null)
					bfrdr2.close();
			}
			catch(Exception e)
			{
				System.out.println("could not close buffered reader: "+e);
			}
			try
			{
				if(rdr1!=null)
					rdr1.close();
			}
			catch(Exception e)
			{
				System.out.println("Could not close reader: "+e);
			}
			try
			{
				if(rdr2!=null)
					rdr2.close();
			}
			catch(Exception e)
			{
				System.out.println("Could not close reader: "+e);
			}
			try
			{
				if(bfwtr!=null)
				{
					bfwtr.close();
				}
			}
			catch(Exception e)
			{
				System.out.println("There was a problem closing the buffered writer: "+e);
			}
			try
			{
				if(wtr!=null)
				{
					wtr.close();
				}
			}
			catch(Exception e)
			{
				System.out.println("There was an error closing the writer: "+e);
			}
		}
	}
}

